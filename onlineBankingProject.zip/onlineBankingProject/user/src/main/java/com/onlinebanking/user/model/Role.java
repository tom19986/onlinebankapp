package com.onlinebanking.user.model;

public enum Role {
    ADMIN,
    USER,
    GUEST;
}