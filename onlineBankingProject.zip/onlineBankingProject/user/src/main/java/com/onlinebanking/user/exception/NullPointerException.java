package com.onlinebanking.user.exception;

public class NullPointerException extends RuntimeException{
    public NullPointerException(String message) {
        super(message);
}}
