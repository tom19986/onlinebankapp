package com.onlinebanking.user.client;

import com.onlinebanking.card.dto.CardRequestDTO;
import com.onlinebanking.card.dto.CardResponseDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class CardClient {

    private final RestTemplate restTemplate;
    @Value("${service.card.url}")
    private  String cardServiceUrl;

    public CardResponseDTO createCard(CardRequestDTO cardRequestDTO) {
        ResponseEntity<CardResponseDTO> response = restTemplate.postForEntity(cardServiceUrl, cardRequestDTO, CardResponseDTO.class);
        return response.getBody();
    }
}
