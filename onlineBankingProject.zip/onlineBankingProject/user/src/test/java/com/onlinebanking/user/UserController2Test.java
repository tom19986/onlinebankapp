package com.onlinebanking.user;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.onlinebanking.user.controller.UserController;
import com.onlinebanking.user.dto.*;
import com.onlinebanking.user.service.UserService;
import com.onlinebanking.user.util.SuccessMessageConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserController2Test {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    private UserRequestDTO userRequestDTO;
    private UserResponseDTO userResponseDTO;
    private LoginRequestDTO loginRequestDTO;
    private PasswordChangeDTO passwordChangeDTO;
    private PasswordUpdateDTO passwordUpdateDTO;

    @BeforeEach
    public void setUp() {
        userRequestDTO = new UserRequestDTO();
        userRequestDTO.setUsername("newuser");
        userRequestDTO.setEmail("newuser@example.com");
        userRequestDTO.setPassword("password");

        userResponseDTO = new UserResponseDTO();
        userResponseDTO.setId(1L);
        userResponseDTO.setUsername("newuser");
        userResponseDTO.setEmail("newuser@example.com");
        userResponseDTO.setMessage(SuccessMessageConstants.USER_REGISTERED_SUCCESS);

        loginRequestDTO = new LoginRequestDTO();
        loginRequestDTO.setUsername("newuser");
        loginRequestDTO.setPassword("password");

        passwordChangeDTO = new PasswordChangeDTO();
        passwordChangeDTO.setNewPassword("newpassword");
        passwordChangeDTO.setConfirmPassword("newpassword");

        passwordUpdateDTO = new PasswordUpdateDTO();
        passwordUpdateDTO.setOldPassword("oldpassword");
        passwordUpdateDTO.setNewPassword("newpassword");
        passwordUpdateDTO.setConfirmPassword("newpassword");
    }

    @Test
    public void testRegisterUser_Successful() {
        when(userService.registerUser(userRequestDTO)).thenReturn(userResponseDTO);
        ResponseEntity<UserResponseDTO> response = userController.registerUser(userRequestDTO);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(userResponseDTO, response.getBody());
    }

    @Test
    public void testGetAllUsers() {
        // Prepare mock data
        UserResponseDTO userResponseDTO = new UserResponseDTO();
        userResponseDTO.setId(1L);
        userResponseDTO.setUsername("newuser");
        userResponseDTO.setEmail("newuser@example.com");

        Page<UserResponseDTO> userPage = new PageImpl<>(Collections.singletonList(userResponseDTO),
                PageRequest.of(0, 10, Sort.by("username").ascending()), 1);

        when(userService.getAllUsers(any(Pageable.class))).thenReturn(userPage);

        // Call the method
        ResponseEntity<Page<UserResponseDTO>> response = userController.getAllUsers(0, 10, "username", "asc");

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().getContent().size());
        assertEquals("newuser", response.getBody().getContent().get(0).getUsername());
    }

    @Test
    public void testGetUserByCriteriaById_Success() {
        // Mock the service to return a user based on criteria
        when(userService.getUserByCriteria(1L, null, null, null)).thenReturn(userResponseDTO);

        // Call the controller method
        ResponseEntity<UserResponseDTO> response = userController.getUserByCriteria(1L, null, null, null);

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userResponseDTO, response.getBody());
    }

    @Test
    public void testGetUserByCriteriaByUsername_Success() {
        // Mock the service to return a user based on criteria
        when(userService.getUserByCriteria(null, "newuser", null, null)).thenReturn(userResponseDTO);

        // Call the controller method
        ResponseEntity<UserResponseDTO> response = userController.getUserByCriteria(null, "newuser", null, null);

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userResponseDTO, response.getBody());
    }

    @Test
    public void testGetUserByCriteriaByEmail_Success() {
        // Mock the service to return a user based on criteria
        when(userService.getUserByCriteria(null, null, "newuser@example.com", null)).thenReturn(userResponseDTO);

        // Call the controller method
        ResponseEntity<UserResponseDTO> response = userController.getUserByCriteria(null, null, "newuser@example.com", null);

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userResponseDTO, response.getBody());
    }

    @Test
    public void testGetUserByCriteriaByPhone_Success() {
        // Mock the service to return a user based on criteria
        when(userService.getUserByCriteria(null, null, null, "1234567890")).thenReturn(userResponseDTO);

        // Call the controller method
        ResponseEntity<UserResponseDTO> response = userController.getUserByCriteria(null, null, null, "1234567890");

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userResponseDTO, response.getBody());
    }

    @Test
    public void testDeleteUserById() {
        when(userService.deleteUserById(any(Long.class))).thenReturn(SuccessMessageConstants.USER_DELETED_SUCCESS);

        ResponseEntity<String> response = userController.deleteUserById(1L);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(SuccessMessageConstants.USER_DELETED_SUCCESS, response.getBody());
    }

    @Test
    public void testLoginUser() {
        when(userService.loginUser(any(LoginRequestDTO.class))).thenReturn(SuccessMessageConstants.LOGIN_SUCCESS);

        ResponseEntity<String> response = userController.loginUser(loginRequestDTO);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(SuccessMessageConstants.LOGIN_SUCCESS, response.getBody());
    }

    @Test
    public void testLogoutUser() {
        when(userService.logoutUser(any(Long.class))).thenReturn(SuccessMessageConstants.LOGOUT_SUCCESS);

        ResponseEntity<String> response = userController.logoutUser(1L);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(SuccessMessageConstants.LOGOUT_SUCCESS, response.getBody());
    }

    @Test
    public void testForgetPassword() {
        when(userService.forgetPassword(any(Long.class))).thenReturn("Password reset link sent");

        ResponseEntity<String> response = userController.forgetPassword(1L);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Password reset link sent", response.getBody());
    }

    @Test
    public void testChangePassword() {
        when(userService.changePassword(any(Long.class), any(PasswordChangeDTO.class)))
                .thenReturn(SuccessMessageConstants.PASSWORD_UPDATED_SUCCESS);

        ResponseEntity<String> response = userController.changePassword(1L, passwordChangeDTO);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(SuccessMessageConstants.PASSWORD_UPDATED_SUCCESS, response.getBody());
    }

    @Test
    public void testUpdatePassword() {
        when(userService.updatePassword(any(Long.class), any(PasswordUpdateDTO.class)))
                .thenReturn(SuccessMessageConstants.PASSWORD_UPDATED_SUCCESS);

        ResponseEntity<String> response = userController.updatePassword(1L, passwordUpdateDTO);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(SuccessMessageConstants.PASSWORD_UPDATED_SUCCESS, response.getBody());
    }

    @Test
    public void testUnblockUser() {
        when(userService.unblockUser(any(Long.class), any(Long.class)))
                .thenReturn(SuccessMessageConstants.UNBLOCK_SUCCESS);

        ResponseEntity<String> response = userController.unblockUser(1L, 2L);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(SuccessMessageConstants.UNBLOCK_SUCCESS, response.getBody());
    }

    @Test
    public void testGetUsersByCriteria_Successful() {
        // Prepare mock data
        UserResponseDTO userResponseDTO = new UserResponseDTO();
        userResponseDTO.setId(1L);
        userResponseDTO.setUsername("newuser");
        userResponseDTO.setEmail("newuser@example.com");

        // Create a Page object with mock data
        Page<UserResponseDTO> userPage = new PageImpl<>(Collections.singletonList(userResponseDTO),
                PageRequest.of(0, 10, Sort.by("id").ascending()), 1);

        // Mock the service method
        when(userService.getUsersByCriteria(any(String.class), any(String.class), any(String.class), anyList(), any(Pageable.class)))
                .thenReturn(userPage);

        // Call the controller method
        ResponseEntity<Page<UserResponseDTO>> response = userController.getUsersByCriteria(
                null, "newuser@example.com", null, null, 0, 10, "id", "asc");

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        //assertEquals(1, Objects.requireNonNull(response.getBody()).getContent().size());
        //assertEquals("newuser", response.getBody().getContent().get(0).getUsername());
    }
}
