package com.onlinebanking.user;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.onlinebanking.user.dto.UserResponseDTO;
import com.onlinebanking.user.exception.AccountBlockedException;
import com.onlinebanking.user.exception.NullPointerException;
import com.onlinebanking.user.model.Role;
import com.onlinebanking.user.model.User;
import com.onlinebanking.user.repository.UserRepository;
import com.onlinebanking.user.service.UserServiceImpl;
import com.onlinebanking.user.util.ErrorMessageConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.Collections;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class UserServiceImplTest5 {

    @Mock
    private UserRepository userRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private UserServiceImpl userService;

    private Pageable pageable;
    private User user;
    private UserResponseDTO userResponseDTO;

    @BeforeEach
    public void setUp() {
        pageable = Pageable.unpaged(); // or use a specific Pageable implementation as needed
        user = new User();
        userResponseDTO = new UserResponseDTO();
    }

    @Test
    public void testGetUsersByCriteria_Username() {
        // Arrange
        user.setUsername("testuser");
        UserResponseDTO responseDTO = new UserResponseDTO();
        when(userRepository.findByUsernameContainingIgnoreCase(eq("testuser"), any(Pageable.class)))
                .thenReturn(new PageImpl<>(Collections.singletonList(user)));
        when(modelMapper.map(any(User.class), eq(UserResponseDTO.class)))
                .thenReturn(responseDTO);

        // Act
        Page<UserResponseDTO> result = userService.getUsersByCriteria("testuser", null, null, null, pageable);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(responseDTO, result.getContent().get(0));
    }

    @Test
    public void testGetUsersByCriteria_Email() {
        // Arrange
        user.setEmail("test@example.com");
        UserResponseDTO responseDTO = new UserResponseDTO();
        when(userRepository.findByEmailContainingIgnoreCase(eq("test@example.com"), any(Pageable.class)))
                .thenReturn(new PageImpl<>(Collections.singletonList(user)));
        when(modelMapper.map(any(User.class), eq(UserResponseDTO.class)))
                .thenReturn(responseDTO);

        // Act
        Page<UserResponseDTO> result = userService.getUsersByCriteria(null, "test@example.com", null, null, pageable);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(responseDTO, result.getContent().get(0));
    }

    @Test
    public void testGetUsersByCriteria_PhoneNumber() {
        // Arrange
        user.setPhoneNumber("1234567890");
        UserResponseDTO responseDTO = new UserResponseDTO();
        when(userRepository.findByPhoneNumberContainingIgnoreCase(eq("1234567890"), any(Pageable.class)))
                .thenReturn(new PageImpl<>(Collections.singletonList(user)));
        when(modelMapper.map(any(User.class), eq(UserResponseDTO.class)))
                .thenReturn(responseDTO);

        // Act
        Page<UserResponseDTO> result = userService.getUsersByCriteria(null, null, "1234567890", null, pageable);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(responseDTO, result.getContent().get(0));
    }

    @Test
    public void testGetUsersByCriteria_Roles() {
        // Arrange
        Role role = null;
        user.setRole(role);
        UserResponseDTO responseDTO = new UserResponseDTO();
        when(userRepository.findByRoleIn(eq(Collections.singletonList(role)), any(Pageable.class)))
                .thenReturn(new PageImpl<>(Collections.singletonList(user)));
        when(modelMapper.map(any(User.class), eq(UserResponseDTO.class)))
                .thenReturn(responseDTO);

        // Act
        Page<UserResponseDTO> result = userService.getUsersByCriteria(null, null, null, Collections.singletonList(role), pageable);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(responseDTO, result.getContent().get(0));
    }

    @Test

    public void testGetUsersByCriteria_AllNull() {
        // Arrange
        Pageable pageable = Pageable.unpaged(); // or use a specific Pageable implementation if needed
        NullPointerException thrown = assertThrows(NullPointerException.class, () -> {
            userService.getUsersByCriteria(null, null, null, null, pageable);
        });
      assertEquals(ErrorMessageConstants.SELECT_ATLEAST_ONE, thrown.getMessage());
    }
}
