package com.onlinebanking.user;

import com.onlinebanking.user.dto.*;
import com.onlinebanking.user.exception.*;
import com.onlinebanking.user.model.Role;
import com.onlinebanking.user.model.User;
import com.onlinebanking.user.repository.UserRepository;
import com.onlinebanking.user.service.UserServiceImpl;
import com.onlinebanking.user.util.ErrorMessageConstants;
import com.onlinebanking.user.util.SuccessMessageConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;
    @Mock
    private User user;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private UserServiceImpl userService;


    private UserResponseDTO userResponseDTO;

    @BeforeEach
    public void setUp() {
        user = new User();
        user.setId(1L);
        user.setUsername("testuser");
        user.setEmail("testuser@example.com");
        user.setPhoneNumber("1234567890");
        user.setRole(Role.USER);
        user.setPassword("password");
        user.setRegisterDate(LocalDateTime.now());
        user.setBlock(false);
        user.setLogin(true);

        userResponseDTO = new UserResponseDTO();
        userResponseDTO.setId(1L);
        userResponseDTO.setUsername("testuser");
        userResponseDTO.setEmail("testuser@example.com");
        userResponseDTO.setPhoneNumber("1234567890");
        userResponseDTO.setRole(Role.USER);
        userResponseDTO.setMessage(SuccessMessageConstants.USER_REGISTERED_SUCCESS);
    }

    @Test
    public void testGetUserByCriteriaById() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(modelMapper.map(user, UserResponseDTO.class)).thenReturn(userResponseDTO);

        UserResponseDTO response = userService.getUserByCriteria(1L, null, null, null);

        assertNotNull(response);
        assertEquals("testuser", response.getUsername());
    }

    @Test
    public void testGetUserByCriteriaByUsername() {
        when(userRepository.findByUsername("testuser")).thenReturn(user);
        when(modelMapper.map(user, UserResponseDTO.class)).thenReturn(userResponseDTO);

        UserResponseDTO response = userService.getUserByCriteria(null, "testuser", null, null);

        assertNotNull(response);
        assertEquals("testuser", response.getUsername());
    }
    @Test
    public void testGetUserByCriteriaByEmail() {
        when(userRepository.findByEmail("testuser@example.com")).thenReturn(user);
        when(modelMapper.map(user, UserResponseDTO.class)).thenReturn(userResponseDTO);

        UserResponseDTO response = userService.getUserByCriteria(null, null, "testuser@example.com", null);

        assertNotNull(response);
        assertEquals("testuser@example.com", response.getEmail());
    }
    @Test
    public void testGetUserByCriteriaByPhoneNumber() {
        when(userRepository.findByPhoneNumber("1234567890")).thenReturn(user);
        when(modelMapper.map(user, UserResponseDTO.class)).thenReturn(userResponseDTO);

        UserResponseDTO response = userService.getUserByCriteria(null, null, null, "1234567890");

        assertNotNull(response);
        assertEquals("1234567890", response.getPhoneNumber());
    }
    @Test
    public void testGetUserByCriteriaByPhone() {
        when(userRepository.findByPhoneNumber("1234567899")).thenReturn(user);
        when(modelMapper.map(user, UserResponseDTO.class)).thenReturn(userResponseDTO);

        UserResponseDTO response = userService.getUserByCriteria(null, null, null, "1234567899");

        assertNotNull(response);
        assertEquals("1234567890", response.getPhoneNumber());
    }

    @Test
    public void testRegisterUser() {
        UserRequestDTO requestDTO = new UserRequestDTO();
        requestDTO.setUsername("newuser");
        requestDTO.setEmail("newuser@example.com");
        requestDTO.setPassword("password");

        when(userRepository.existsByUsername("newuser")).thenReturn(false);
        when(userRepository.existsByEmail("newuser@example.com")).thenReturn(false);
        when(modelMapper.map(requestDTO, User.class)).thenReturn(user);
        when(userRepository.save(user)).thenReturn(user);
        when(modelMapper.map(user, UserResponseDTO.class)).thenReturn(userResponseDTO);

        UserResponseDTO response = userService.registerUser(requestDTO);

        assertNotNull(response);
        assertEquals(SuccessMessageConstants.USER_REGISTERED_SUCCESS, response.getMessage());
    }

    @Test
    public void testGetAllUsers() {
        // Create Pageable instance for the first page with 10 items per page
        Pageable pageable = PageRequest.of(0, 10);

        // Create a list of users and a PageImpl<User> with this list
        User user = new User();
        user.setUsername("testuser");// assuming a constructor or setter for username
        List<User> users = Arrays.asList(user);
        Page<User> userPage = new PageImpl<>(users);

        // Create a UserResponseDTO
        UserResponseDTO userResponseDTO = new UserResponseDTO();
        userResponseDTO.setUsername("testuser");// assuming a constructor for username

        // Stub the userRepository to return the userPage when findAll is called
        when(userRepository.findAll(pageable)).thenReturn(userPage);

        // Stub the modelMapper to return a UserResponseDTO when mapping a User
        when(modelMapper.map(user, UserResponseDTO.class)).thenReturn(userResponseDTO);

        // Call the method under test
        Page<UserResponseDTO> responsePage = userService.getAllUsers(pageable);

        // Print the list of UserResponseDTOs to the console
        System.out.println("UserResponseDTO List:");
        for (UserResponseDTO dto : responsePage.getContent()) {
            System.out.println("Username: " + dto.getUsername());
        }

        // Assertions to verify the behavior
        assertNotNull(responsePage);
        assertEquals(1, responsePage.getNumberOfElements());
        assertEquals("testuser", responsePage.getContent().get(0).getUsername());
    }



    @Test
    public void testDeleteUserById() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        doNothing().when(userRepository).delete(user);

        String message = userService.deleteUserById(1L);

        assertEquals(SuccessMessageConstants.USER_DELETED_SUCCESS, message);
    }

    @Test
    public void testLoginUser_SuccessfulLogin() {
        // Arrange
        LoginRequestDTO loginRequestDTO = new LoginRequestDTO();
        loginRequestDTO.setUsername("testuser");
        loginRequestDTO.setPassword("password");


        when(userRepository.findByUsername("testuser")).thenReturn(user);

        // Act
        String result = userService.loginUser(loginRequestDTO);

        // Assert
        assertEquals(SuccessMessageConstants.LOGIN_SUCCESS, result);
        assertEquals(0, user.getInvalidAttemptCount()); // Ensure invalid attempt count is reset
        assertTrue(user.isLogin()); // Ensure user login state is updated
        assertNotNull(user.getLastLoginDate()); // Ensure last login date is set
        verify(userRepository).save(user); // Ensure save is called
    }
    @Test
    public void testLoginUserBlocked() {
        user.setBlock(true);
        LoginRequestDTO loginRequestDTO = new LoginRequestDTO();
        loginRequestDTO.setUsername("testuser");
        loginRequestDTO.setPassword("password");

        when(userRepository.findByUsername("testuser")).thenReturn(user);

        assertThrows(AccountBlockedException.class, () -> userService.loginUser(loginRequestDTO));
    }


    @Test
    public void testUpdatePassword() {
        // Arrange
        Long userId = 1L;
        PasswordUpdateDTO passwordUpdateDTO = new PasswordUpdateDTO();
        passwordUpdateDTO.setOldPassword("password");
        passwordUpdateDTO.setNewPassword("newPassword");
        passwordUpdateDTO.setConfirmPassword("newPassword");

        User mockUser = new User();
        mockUser.setPassword("password"); // Current password
        when(userRepository.findById(userId)).thenReturn(Optional.of(mockUser));
        String result = userService.updatePassword(userId, passwordUpdateDTO);
        assertEquals(SuccessMessageConstants.PASSWORD_UPDATED_SUCCESS, result);
        verify(userRepository).save(any(User.class)); // Verify save method was called
    }
    @Test
    public void testForgetPassword() {
        // Arrange
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        // Act
        String result = userService.forgetPassword(1L);

        // Assert
        String expectedUrl = SuccessMessageConstants.PASSWORD_RESET_URL + user.getId();
        assertEquals(expectedUrl, result);
    }

    @Test
    public void testChangePassword() {
        PasswordChangeDTO passwordChangeDTO = new PasswordChangeDTO();
        passwordChangeDTO.setNewPassword("newpassword");
        passwordChangeDTO.setConfirmPassword("newpassword");

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(userRepository.save(user)).thenReturn(user);

        String message = userService.changePassword(1L, passwordChangeDTO);

        assertEquals(SuccessMessageConstants.PASSWORD_UPDATED_SUCCESS, message);
    }

    @Test
    public void testUnblockUser() {
        User adminUser = new User();
        adminUser.setId(2L);
        adminUser.setLogin(true);

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(userRepository.findById(2L)).thenReturn(Optional.of(adminUser));
        when(userRepository.save(user)).thenReturn(user);

        String message = userService.unblockUser(1L, 2L);

        assertEquals(SuccessMessageConstants.UNBLOCK_SUCCESS, message);
    }
    @Test
    public void testLogoutUser_SuccessfulLogout() {
        // Arrange

        user.setLogin(true);
        user.setBlock(false);
        when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));
        String result = userService.logoutUser(1L);
        assertEquals(SuccessMessageConstants.LOGOUT_SUCCESS, result);
    }

    @Test
    public void testLogoutUser_UserBlocked() {
        // Arrange
        user.setBlock(true);
        when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));
        AccountBlockedException thrown = assertThrows(AccountBlockedException.class, () -> {
            userService.logoutUser(1L);
        });
        assertEquals(ErrorMessageConstants.ALREADY_ACCOUNT_BLOCKED, thrown.getMessage());
    }

    @Test
    public void testLogoutUser_UserNotLoggedIn() {

        user.setLogin(false);
        user.setBlock(false);
        when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));
        UserNotLoggedInException thrown = assertThrows(UserNotLoggedInException.class, () -> {
            userService.logoutUser(1L);
        });
        assertEquals(ErrorMessageConstants.USER_ALREADY_LOGGEDOUT, thrown.getMessage());
    }

    @Test
    public void testLogoutUser_UserNotFound() {
        // Arrange
        when(userRepository.findById(anyLong())).thenReturn(Optional.empty());

        // Act & Assert
        // Assuming you have a custom exception for user not found
        assertThrows(UserNotFoundException.class, () -> {
            userService.logoutUser(1L);
        });
    }
}
