package com.onlinebanking.card.client;

import com.onlinebanking.account.dto.AccountRequestDTO;
import com.onlinebanking.account.dto.AccountResponseDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;

@Component
@RequiredArgsConstructor
public class AccountClient {

    private final RestTemplate restTemplate;

    @Value("${service.account.url}")
    private String accountServiceUrl;

    /**
     * Adds an amount to an account.
     * @param accountNumber the account number to which the amount will be added.
     * @param amount the amount to be added.
     * @return the response from the account service.
     */
    public AccountResponseDTO addAmount(String accountNumber, BigDecimal amount) {

        String url = accountServiceUrl + "/add-amount";

        // Create an AccountRequestDTO to send the account number and amount in the request body
        AccountRequestDTO requestDTO = new AccountRequestDTO();
        requestDTO.setAccountNumber(accountNumber);
        requestDTO.setAmount(amount);

        // Send the request with the requestDTO as the body
        ResponseEntity<AccountResponseDTO> response = restTemplate.postForEntity(
                url,
                requestDTO,
                AccountResponseDTO.class
        );

        // Check if the response is successful
        if (response.getStatusCode().is2xxSuccessful()) {
            return response.getBody();
        } else {
            throw new RuntimeException("Failed to add amount to account. Status: " + response.getStatusCode());
        }
    }
    public AccountResponseDTO withdrawAmount(String accountNumber, BigDecimal amount) {

        String url = accountServiceUrl + "/withdraw-amount";

        // Create an AccountRequestDTO to send the account number and amount in the request body
        AccountRequestDTO requestDTO = new AccountRequestDTO();
        requestDTO.setAccountNumber(accountNumber);
        requestDTO.setAmount(amount);

        // Send the request with the requestDTO as the body
        ResponseEntity<AccountResponseDTO> response = restTemplate.postForEntity(
                url,
                requestDTO,
                AccountResponseDTO.class
        );

        // Check if the response is successful
        if (response.getStatusCode().is2xxSuccessful()) {
            return response.getBody();
        } else {
            throw new RuntimeException("Failed to withdraw amount from account. Status: " + response.getStatusCode());
        }
    }
}
