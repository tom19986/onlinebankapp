package com.onlinebanking.card.util;

public final class ErrorMessageUtil {



    private ErrorMessageUtil() {
        // Private constructor to prevent instantiation
    }

    public static final String CARD_NOT_FOUND = "Card not found.";
    public static final String INVALID_CARD_OPERATION = "Invalid operation on the card.";
    public static final String AMOUNT_MUST_BE_GREATER_THAN_ZERO = "Amount must be greater than zero.";
    public static final String CARD_ALREADY_DEACTIVATED = "Card is already deactivated.";
    public static final String SELECT_ATLEAST_ONE = "At least one search criteria must be provided";


    public static final String AMOUNT_MUST_BE_GREATER_THAN_OR_EQUAL_TO_ZERO = "Amount must be greater than or equal to zero.";
    // Add more error messages as needed
    public static final String INSUFFICIENT_FUNDS = "Insufficient funds for this transaction.";
    public static final String INVALID_AMOUNT = "Invalid amount";
    public static final String NEED_TO_ACTIVATE = "INVALID STATUS:need to activate your card";

    public static final String ENTER_CORRECT_PIN = "ENTER_CORRECT_PIN";
    public static final String ENTER_CORRECT_CVV = "ENTER_CORRECT_CVV";
    public static final String ENTER_CORRECT_EXPIRY_YEAR = "ENTER_CORRECT_EXPIRY_YEAR";

    public static final String ENTER_CORRECT_EXPIRY_MONTH = "ENTER_CORRECT_EXPIRY_MONTH";


}
