package com.onlinebanking.card.service;

import com.onlinebanking.card.exceptions.CardNotFoundException;
import com.onlinebanking.card.model.Card;
import com.onlinebanking.card.repository.CardRepository;
import com.onlinebanking.card.util.ErrorMessageUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class GetCardService {
    private final CardRepository cardRepository;
    //--private------
    public Card getByCardNumber(String cardNumber){
        Card card= cardRepository.findByCardNumber(cardNumber);
        if (card == null) {
            throw new CardNotFoundException(ErrorMessageUtil.CARD_NOT_FOUND);
        }return card;
    }
    public Card getByCardId(Long id){
        return cardRepository.findById(id)
                .orElseThrow(() -> new CardNotFoundException(ErrorMessageUtil.CARD_NOT_FOUND));

    }

    public Card getByAccountNumber(String accountNumber){
        Card card= cardRepository.findByAccountNumber(accountNumber);
        if (card == null) {
            throw   new CardNotFoundException(ErrorMessageUtil.CARD_NOT_FOUND);
        }return card;
    }
    public Card getByCardHolderName(String cardHolderName){
        Card card= cardRepository.findByCardHolderName(cardHolderName);
        if (card == null) {
            throw new CardNotFoundException(ErrorMessageUtil.CARD_NOT_FOUND);
        }return card;
    }
}
