package com.onlinebanking.card.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class CardDetailsRequestDTO {

    @NotBlank(message = "Card number is required")
    @Pattern(regexp = "\\d{16}", message = "Card number must be 16 digits")
    private String cardNumber;

    @NotBlank(message = "PIN is required")
    @Pattern(regexp = "\\d{4}", message = "PIN must be 4 digits")
    private String pin;

    @NotBlank(message = "CVV is required")
    @Pattern(regexp = "\\d{3}", message = "CVV must be 3 digits")
    private String cvv;

    @NotNull(message = "Expiry year is required")
    private Integer expiryYear;

    @NotNull(message = "Expiry month is required")
    @Size(min = 1, max = 2, message = "Expiry month must be between 1 and 2 digits")
    private Integer expiryMonth;

    @NotNull(message = "balance is required.")
    @DecimalMin(value = "0.0", inclusive = true, message = " balance must be at least 0.")
    private BigDecimal amount;
}
