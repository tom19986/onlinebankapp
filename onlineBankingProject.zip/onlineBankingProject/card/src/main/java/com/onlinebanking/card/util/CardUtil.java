package com.onlinebanking.card.util;

import java.security.SecureRandom;

public class CardUtil {

    private static final int CARD_NUMBER_LENGTH = 16; // Desired length of the card number
    private static final SecureRandom random = new SecureRandom();

    public static String generateCardNumber() {
        StringBuilder cardNumber = new StringBuilder(CARD_NUMBER_LENGTH);

        // Generate digits only
        for (int i = 0; i < CARD_NUMBER_LENGTH; i++) {
            cardNumber.append(random.nextInt(10)); // Append a digit from 0 to 9
        }

        return cardNumber.toString();
    }

    public static String generateCvv() {
        // Generate a 3-digit CVV
        return String.valueOf(random.nextInt(900) + 100);
    }

    public static String generatePin() {
        // Generate a 4-digit PIN
        return String.format("%04d", random.nextInt(10000)); // Pads with leading zeros if necessary
    }
}
