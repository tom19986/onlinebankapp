package com.onlinebanking.card.model;

public enum CardType {
    DEBIT,
    CREDIT,
    PREPAID
}
