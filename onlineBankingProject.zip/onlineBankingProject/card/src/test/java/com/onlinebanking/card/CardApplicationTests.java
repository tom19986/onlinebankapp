package com.onlinebanking.card;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.onlinebanking.card.controller.CardController;
import com.onlinebanking.card.dto.CardRequestDTO;
import com.onlinebanking.card.dto.CardResponseDTO;
import com.onlinebanking.card.model.CardType;
import com.onlinebanking.card.service.CardService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.hamcrest.Matchers.is;

@WebMvcTest(CardController.class)
public class CardApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private CardService cardService;

	@Autowired
	private ObjectMapper objectMapper;

	@Test
	public void testCreateCard() throws Exception {
		// Arrange: Create a CardRequestDTO object with sample data
		CardRequestDTO cardRequestDTO = new CardRequestDTO();
		cardRequestDTO.setCardHolderName("John Doe");
		cardRequestDTO.setPin("1234");
		cardRequestDTO.setCardType(CardType.DEBIT);
		cardRequestDTO.setInitialBalance(new BigDecimal("1000.00"));
		cardRequestDTO.setAccountId(1L);

		// Arrange: Create a mocked CardResponseDTO object
		CardResponseDTO cardResponseDTO = new CardResponseDTO();
		cardResponseDTO.setCardHolderName("John Doe");
		cardResponseDTO.setCardNumber("1234567890123456");

		// Mocking: Define behavior for cardService.createCard() method
		Mockito.when(cardService.createCard(Mockito.any(CardRequestDTO.class)))
				.thenReturn(cardResponseDTO);

		// Act & Assert: Perform a POST request and verify the response
		mockMvc.perform(post("/cards")  // Adjust this endpoint if needed
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(cardRequestDTO)))
				.andExpect(status().isOk()) // Expecting HTTP 200 OK
				.andExpect(jsonPath("$.cardHolderName", is("John Doe"))) // Validate response content
				.andExpect(jsonPath("$.cardNumber", is("1234567890123456")));
	}
}
