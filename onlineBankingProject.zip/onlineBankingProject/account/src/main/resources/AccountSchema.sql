-- SQL script to create the 'bankAccount' table

CREATE TABLE bankAccount (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    accountNumber VARCHAR(255) NOT NULL UNIQUE,
    accountHolderName VARCHAR(255),
    accountType VARCHAR(255) NOT NULL,
    balance DECIMAL(20, 2) DEFAULT 0.00,
    lastUpdateBalanceDate TIMESTAMP,
    lastUpdatedDate TIMESTAMP,
    currency VARCHAR(255) NOT NULL,
    status VARCHAR(255) NOT NULL,
    createdDate TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    userId BIGINT
);


