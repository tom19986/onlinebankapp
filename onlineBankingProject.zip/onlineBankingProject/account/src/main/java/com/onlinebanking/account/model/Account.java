package com.onlinebanking.account.model;



import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "bankAccount")
public class Account {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = false, nullable = false)
    private String accountNumber;

    private String accountHolderName;
    @Enumerated(EnumType.STRING)
    private AccountType accountType;
    private BigDecimal balance;

    private LocalDateTime lastUpdatedDate;
    @Enumerated(EnumType.STRING)
    private Currency currency;
    @Enumerated(EnumType.STRING)
    private AccountStatus status;
    private LocalDateTime createdDate;
    private Long userId;







}

