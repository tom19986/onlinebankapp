package com.onlinebanking.account.model;

public enum AccountStatus {
    ACTIVE,
    CLOSED,
    PENDING
}
