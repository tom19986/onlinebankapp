package com.onlinebanking.account;

import com.onlinebanking.account.controller.AccountController;
import com.onlinebanking.account.dto.AccountRequestDTO;
import com.onlinebanking.account.dto.AccountResponseDTO;
import com.onlinebanking.account.model.AccountStatus;
import com.onlinebanking.account.service.AccountService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AccountControllerTest {

    @Mock
    private AccountService accountService;

    @InjectMocks
    private AccountController accountController;

    private AccountRequestDTO accountRequestDTO;
    private AccountResponseDTO accountResponseDTO;

    @BeforeEach
    public void setUp() {
        accountRequestDTO = new AccountRequestDTO();
        accountRequestDTO.setAccountNumber("ACC123456");
        accountRequestDTO.setAccountHolderName("John Doe");

        accountResponseDTO = new AccountResponseDTO();
        accountResponseDTO.setAccountNumber("ACC123456");
        accountResponseDTO.setAccountHolderName("John Doe");
        accountResponseDTO.setStatus(AccountStatus.ACTIVE);
        accountResponseDTO.setBalance(BigDecimal.valueOf(1000));
    }

    @Test
    public void testCreateAccount() {
        when(accountService.createAccount(accountRequestDTO)).thenReturn(accountResponseDTO);

        AccountResponseDTO response = accountController.createAccount(accountRequestDTO);

        assertEquals(accountResponseDTO, response);
    }

    @Test
    public void testGetAccountByCriteria() {
        when(accountService.getAccountByCriteria(null, "ACC123456", null, null)).thenReturn(accountResponseDTO);

        AccountResponseDTO response = accountController.getAccountByCriteria(null, "ACC123456", null, null);

        assertEquals(accountResponseDTO, response);
    }

    @Test
    public void testGetAllAccounts() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<AccountResponseDTO> accountPage = new PageImpl<>(Collections.singletonList(accountResponseDTO), pageable, 1);

        when(accountService.getAllAccounts(pageable)).thenReturn(accountPage);

        Page<AccountResponseDTO> response = accountController.getAllAccounts(pageable);

        assertEquals(1, response.getContent().size());
        assertEquals("ACC123456", response.getContent().get(0).getAccountNumber());
    }

    @Test
    public void testGetUsersByCriteria() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<AccountResponseDTO> accountPage = new PageImpl<>(Collections.singletonList(accountResponseDTO), pageable, 1);

        when(accountService.getAccountsByCriteria("John Doe", "ACC123456", null, pageable)).thenReturn(accountPage);

        ResponseEntity<Page<AccountResponseDTO>> response = accountController.getUsersByCriteria(
                "John Doe", null, null, 0, 10, "id", "asc");

        //assertEquals(HttpStatus.OK, response.getStatusCode());
        //assertEquals(1, response.getBody().getContent().size());
        assertEquals("ACC123456", response.getBody().getContent().get(0).getAccountNumber());
    }

    @Test
    public void testChangeAccountType() {
        when(accountService.changeAccountType("ACC123456", "SAVINGS")).thenReturn(accountResponseDTO);

        AccountResponseDTO response = accountController.changeAccountType("ACC123456", "SAVINGS");

        assertEquals(accountResponseDTO, response);
    }

    @Test
    public void testChangeAccountStatus() {
        when(accountService.changeAccountStatus("ACC123456", "INACTIVE")).thenReturn(accountResponseDTO);

        AccountResponseDTO response = accountController.changeAccountStatus("ACC123456", "INACTIVE");

        assertEquals(accountResponseDTO, response);
    }

    @Test
    public void testGetBalance() {
        when(accountService.getBalance(accountRequestDTO)).thenReturn(BigDecimal.valueOf(1000));

        BigDecimal response = accountController.getBalance(accountRequestDTO);

        assertEquals(BigDecimal.valueOf(1000), response);
    }

    @Test
    public void testSetBalance() {
        when(accountService.setBalance("ACC123456", BigDecimal.valueOf(1500))).thenReturn(accountResponseDTO);

        AccountResponseDTO response = accountController.setBalance("ACC123456", BigDecimal.valueOf(1500));

        assertEquals(accountResponseDTO, response);
    }

    @Test
    public void testActivateBankAccount() {
        when(accountService.activateBankAccount("ACC123456")).thenReturn(accountResponseDTO);

        AccountResponseDTO response = accountController.activateBankAccount("ACC123456");

        assertEquals(accountResponseDTO, response);
    }

    @Test
    public void testAddAmount() {
        when(accountService.AddAmount("ACC123456", BigDecimal.valueOf(500))).thenReturn(accountResponseDTO);

        AccountResponseDTO response = accountController.addAmount("ACC123456", BigDecimal.valueOf(500));

        assertEquals(accountResponseDTO, response);
    }
}
