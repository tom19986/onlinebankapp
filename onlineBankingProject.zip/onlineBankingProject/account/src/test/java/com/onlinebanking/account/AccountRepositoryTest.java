package com.onlinebanking.account;

import com.onlinebanking.account.model.Account;
import com.onlinebanking.account.model.AccountStatus;
import com.onlinebanking.account.repository.AccountRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.Arrays;
import java.util.List;


import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

@SpringBootTest
class AccountRepositoryTest {
	@Autowired
	private AccountRepository accountRepository;

	@BeforeEach
	public void setUp() {
		// Clear the repository and populate it with test data before each test
		accountRepository.deleteAll();

		// Add some test accounts
		Account account1 = new Account();
		account1.setAccountNumber("ACC123456");
		account1.setAccountHolderName("John Doe");
		account1.setStatus(AccountStatus.ACTIVE);
		account1.setUserId(1L);
		accountRepository.save(account1);

		Account account2 = new Account();
		account2.setAccountNumber("ACC789012");
		account2.setAccountHolderName("Jane Smith");
		account2.setStatus(AccountStatus.PENDING);
		account2.setUserId(2L);
		accountRepository.save(account2);
	}

	@Test
	public void whenFindByAccountNumber_thenReturnAccount() {
		// When
		Account found = accountRepository.findByAccountNumber("ACC123456");

		// Then
		assertNotNull(found);
		assertEquals("John Doe", found.getAccountHolderName());
	}

	@Test
	public void whenFindByAccountHolderName_thenReturnAccount() {
		// When
		Account found = accountRepository.findByAccountHolderName("Jane Smith");

		// Then
		assertNotNull(found);
		assertEquals("ACC789012", found.getAccountNumber());
	}

	@Test
	public void whenFindByAccountHolderNameContainingIgnoreCase_thenReturnPageOfAccounts() {
		// Given
		Pageable pageable = PageRequest.of(0, 10);

		// When
		Page<Account> page = accountRepository.findByAccountHolderNameContainingIgnoreCase("smith", pageable);

		// Then
		assertNotNull(page);
		assertTrue(page.hasContent());
		assertEquals(1, page.getTotalElements());
		assertEquals("Jane Smith", page.getContent().get(0).getAccountHolderName());
	}

	@Test
	public void whenFindByStatusIn_thenReturnPageOfAccounts() {
		// Given
		Pageable pageable = PageRequest.of(0, 10);
		List<AccountStatus> statuses = Arrays.asList(AccountStatus.ACTIVE);

		// When
		Page<Account> page = accountRepository.findByStatusIn(statuses, pageable);

		// Then
		assertNotNull(page);
		assertTrue(page.hasContent());
		assertEquals(1, page.getTotalElements());
		assertEquals("ACC123456", page.getContent().get(0).getAccountNumber());
	}

	@Test
	public void whenFindByUserId_thenReturnAccount() {
		// When
		Account found = accountRepository.findByUserId(1L);

		// Then
		assertNotNull(found);
		assertEquals("ACC123456", found.getAccountNumber());
	}

}
