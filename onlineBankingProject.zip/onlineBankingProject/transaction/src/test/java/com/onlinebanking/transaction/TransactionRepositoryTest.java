//package com.onlinebanking.transaction;
//
//import com.onlinebanking.account.model.Account;
//import com.onlinebanking.account.model.AccountType;
//import com.onlinebanking.transaction.model.Transaction;
//import com.onlinebanking.transaction.model.TransactionType;
//import com.onlinebanking.transaction.repository.TransactionRepository;
//
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Page;
//
//import java.time.LocalDate;
//import java.util.List;
//
//@SpringBootTest
//public class TransactionRepositoryTest {
//
//    @Autowired
//    private TransactionRepository transactionRepository;
//
//    private Transaction transaction;
//
//
//    @BeforeEach
//    public void setUp() {
//        // Initialize and save test users
//        transaction = new Transaction();
//
//        transaction.setAccountId(123L);
//        transaction.setTransactionDate(LocalDate.now());
//        transactionRepository.save(transaction);
//
//    }
//
//    @AfterEach
//    public void tearDown() {
//        // Clean up test data
//        transactionRepository.deleteAll();
//    }
//    @Test
//    public void testFindByTransactionId() {
//        Transaction foundTransaction = transactionRepository.findByTransactionId(transaction.getTransactionId());
//        Assertions.assertNotNull(foundTransaction, "Transaction should not be null");
//        Assertions.assertEquals(transaction.getTransactionId(), foundTransaction.getTransactionId(), "Transaction IDs should match");
//    }
//
//    @Test
//    public void testFindByAccountId() {
//        Transaction foundTransaction = transactionRepository.findByAccountId(transaction.getAccountId());
//        Assertions.assertNotNull(foundTransaction, "Transaction should not be null");
//        Assertions.assertEquals(transaction.getAccountId(), foundTransaction.getAccountId(), "Account IDs should match");
//    }
//
//
//        @Test
//        public void testFindByTransactionBetweenDate() {
//        Pageable pageable = PageRequest.of(0, 10);
//            LocalDate startDate = LocalDate.now().minusDays(7);
//            LocalDate endDate = LocalDate.now();
//        Page<Transaction> transactionPage = transactionRepository.findByTransactionDateBetween(startDate,endDate, pageable);
//        Assertions.assertTrue(transactionPage.hasContent());
//        Assertions.assertEquals(123L, transactionPage.getContent().get(0).getAccountId());
//    }
//
//
//}
