package com.onlinebanking.transaction.service;

import com.onlinebanking.transaction.dto.TransactionRequestDTO;
import com.onlinebanking.transaction.dto.TransactionResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public interface TransactionService {
    TransactionResponseDTO createTransaction(TransactionRequestDTO transactionRequestDTO);
    TransactionResponseDTO getTransactionById(Long transactionId);
    Page<TransactionResponseDTO> getAllTransactions(int page, int size, String sortBy, String sortDir);
    List<TransactionResponseDTO> getTransactionsByCardNumber(String cardNumber);
    String deleteTransaction(Long transactionId);
    public BigDecimal getCardBalance(String cardNumber);
    Page<TransactionResponseDTO> getTransactionsByCardNumberAndDateRange(String cardNumber, LocalDate startDate, LocalDate endDate, Pageable pageable);


    }
