package com.onlinebanking.transaction.controller;

import com.onlinebanking.transaction.dto.TransactionRequestDTO;
import com.onlinebanking.transaction.dto.TransactionResponseDTO;
import com.onlinebanking.transaction.service.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
public class TransactionController {

    private final TransactionService transactionService;


@PostMapping("/create")
public ResponseEntity<TransactionResponseDTO> createTransaction(@RequestBody TransactionRequestDTO transactionRequestDTO) {
    try {
        TransactionResponseDTO responseDTO = transactionService.createTransaction(transactionRequestDTO);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    } catch (Exception e) {
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }
}

    @GetMapping("/{transactionId}")
    public ResponseEntity<TransactionResponseDTO> getTransactionById(@PathVariable Long transactionId) {
        TransactionResponseDTO response = transactionService.getTransactionById(transactionId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    @GetMapping("/balance/{cardNumber}")
    public ResponseEntity<BigDecimal> getBalance(@PathVariable String cardNumber) {
        BigDecimal response = transactionService.getCardBalance(cardNumber);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<Page<TransactionResponseDTO>> getAllTransactions(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "transactionDate") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        Page<TransactionResponseDTO> response = transactionService.getAllTransactions(page, size, sortBy, sortDir);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }



    @GetMapping("/card/{cardNumber}")
    public ResponseEntity<List<TransactionResponseDTO>> getTransactionsByCardNumber(@PathVariable String cardNumber) {
        List<TransactionResponseDTO> responses = transactionService.getTransactionsByCardNumber(cardNumber);
        return new ResponseEntity<>(responses, HttpStatus.OK);
    }


    @DeleteMapping("/{transactionId}")
    public ResponseEntity<String> deleteTransaction(@PathVariable Long transactionId) {
        String message = transactionService.deleteTransaction(transactionId);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

    @GetMapping("/filter")
    public ResponseEntity<Page<TransactionResponseDTO>> getTransactionsByCardIdAndDateRange(
            @RequestParam String cardNumber,
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "transactionDate") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir) {

        Pageable pageable = PageRequest.of(page, size,
                sortDir.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending());

        Page<TransactionResponseDTO> transactions = transactionService.getTransactionsByCardNumberAndDateRange(cardNumber, startDate, endDate, pageable);
        return ResponseEntity.ok(transactions);
    }


    //----------

}
