package com.onlinebanking.transaction.util;

public class SuccessMessageUtil {
    public static final String TRANSACTION_CREATED_SUCCESSFULLY = "Transaction created successfully.";
    public static final String TRANSACTION_UPDATED_SUCCESSFULLY = "Transaction updated successfully.";
    public static final String TRANSACTION_DELETED_SUCCESSFULLY = "Transaction deleted successfully.";
}
