package com.onlinebanking.transaction.dto;

import com.onlinebanking.transaction.model.TransactionType;
import jakarta.validation.constraints.*;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class TransactionRequestDTO {

    @NotBlank(message = "Card number is required")
    @Pattern(regexp = "\\d{16}", message = "Card number must be 16 digits")
    private String cardNumber;

    @NotBlank(message = "PIN is required")
    @Pattern(regexp = "\\d{4}", message = "PIN must be 4 digits")
    private String pin;

    @NotBlank(message = "CVV is required")
    @Pattern(regexp = "\\d{3}", message = "CVV must be 3 digits")
    private String cvv;

    @NotNull(message = "Expiry year is required")
    private Integer expiryYear;

    @NotNull(message = "Expiry month is required")
    @Size(min = 1, max = 2, message = "Expiry month must be between 1 and 2 digits")
    private Integer expiryMonth;


    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be greater than zero")
    private BigDecimal amount;

    @Size(max = 255, message = "Description must be 255 characters or less")
    private String description;
    @NotNull(message = "Transaction type required")
    private TransactionType transactionType;


}
