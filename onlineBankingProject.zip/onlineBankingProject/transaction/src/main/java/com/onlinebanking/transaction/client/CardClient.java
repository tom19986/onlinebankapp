package com.onlinebanking.transaction.client;

import com.onlinebanking.card.dto.CardDetailsRequestDTO;
import com.onlinebanking.card.dto.CardResponseDTO;
import com.onlinebanking.transaction.dto.TransactionRequestDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@RequiredArgsConstructor
@Component
public class CardClient {

    private final RestTemplate restTemplate;

    @Value("${service.card.url}")
    private String cardServiceUrl;
    public CardDetailsRequestDTO mapToCardDetailsRequestDTO(TransactionRequestDTO transactionRequestDTO) {
        CardDetailsRequestDTO cardDetailsRequestDTO = new CardDetailsRequestDTO();
        cardDetailsRequestDTO.setCardNumber(transactionRequestDTO.getCardNumber());
        cardDetailsRequestDTO.setPin(transactionRequestDTO.getPin());
        cardDetailsRequestDTO.setCvv(transactionRequestDTO.getCvv());
        cardDetailsRequestDTO.setExpiryYear(transactionRequestDTO.getExpiryYear());
        cardDetailsRequestDTO.setExpiryMonth(transactionRequestDTO.getExpiryMonth());
        cardDetailsRequestDTO.setAmount(transactionRequestDTO.getAmount());
        return cardDetailsRequestDTO;
    }


    public CardResponseDTO getBalance(String cardNumber) {
        ResponseEntity<CardResponseDTO> response = restTemplate.getForEntity(
                cardServiceUrl + "search?cardNumber=" + cardNumber,
                CardResponseDTO.class
        );
        return response.getBody();
    }

    public CardResponseDTO withdrawAmount(TransactionRequestDTO transactionRequestDTO) {
        CardDetailsRequestDTO cardDetailsRequestDTO = mapToCardDetailsRequestDTO(transactionRequestDTO);
        ResponseEntity<CardResponseDTO> response = restTemplate.postForEntity(
                cardServiceUrl + "withdraw",
                cardDetailsRequestDTO,
                CardResponseDTO.class
        );
        return response.getBody();
    }

    public CardResponseDTO addAmount(TransactionRequestDTO transactionRequestDTO) {
        CardDetailsRequestDTO cardDetailsRequestDTO = mapToCardDetailsRequestDTO(transactionRequestDTO);
        ResponseEntity<CardResponseDTO> response = restTemplate.postForEntity(
                cardServiceUrl + "add",
                cardDetailsRequestDTO,
                CardResponseDTO.class
        );
        return response.getBody();
    }

}
