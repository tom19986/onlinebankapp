package com.onlinebanking.transaction.service;

import com.onlinebanking.card.dto.CardDetailsRequestDTO;
import com.onlinebanking.card.dto.CardResponseDTO;
import com.onlinebanking.transaction.client.CardClient;

import com.onlinebanking.transaction.dto.TransactionRequestDTO;
import com.onlinebanking.transaction.dto.TransactionResponseDTO;
import com.onlinebanking.transaction.exception.CardServiceException;
import com.onlinebanking.transaction.exception.InsufficientFundsException;
import com.onlinebanking.transaction.exception.TransactionNotFoundException;
import com.onlinebanking.transaction.model.Transaction;
import com.onlinebanking.transaction.model.TransactionType;
import com.onlinebanking.transaction.repository.TransactionRepository;
import com.onlinebanking.transaction.util.ErrorMessageUtil;
import com.onlinebanking.transaction.util.SuccessMessageUtil;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final ModelMapper modelMapper;
    private final CardClient cardClient;


    @Override
    public BigDecimal getCardBalance(String cardNumber){
        // Fetch card balance
        CardResponseDTO cardResponse = cardClient.getBalance(cardNumber);

        if (cardResponse == null) {
            throw new CardServiceException(ErrorMessageUtil.CARD_SERVICE_ERROR);
        }
        return cardResponse.getBalance();
    }
    @Override
    @Transactional
    public TransactionResponseDTO createTransaction(TransactionRequestDTO transactionRequestDTO) {
        // Fetch card balance
        CardResponseDTO cardResponse = cardClient.getBalance(transactionRequestDTO.getCardNumber());

        if (cardResponse == null) {
            throw new CardServiceException(ErrorMessageUtil.CARD_SERVICE_ERROR);
        }

        BigDecimal cardBalance = cardResponse.getBalance();
        BigDecimal transactionAmount = transactionRequestDTO.getAmount();

        // Validate balance for debit transactions
        if (transactionRequestDTO.getTransactionType() == TransactionType.DEBIT) {
            if (cardBalance.compareTo(transactionAmount) < 0) {
                throw new InsufficientFundsException(ErrorMessageUtil.INSUFFICIENT_FUNDS);
            }
        }

        // Execute the transaction
        if (transactionRequestDTO.getTransactionType() == TransactionType.DEBIT) {
            cardClient.withdrawAmount(transactionRequestDTO);
        } else if (transactionRequestDTO.getTransactionType() == TransactionType.CREDIT) {
            cardClient.addAmount(transactionRequestDTO);
        } else {
            throw new IllegalArgumentException("Invalid transaction type");
        }

        // Fetch the updated balance
        CardResponseDTO updatedCardResponse = cardClient.getBalance(transactionRequestDTO.getCardNumber());
        if (updatedCardResponse == null) {
            throw new CardServiceException(ErrorMessageUtil.CARD_SERVICE_ERROR);
        }

        BigDecimal updatedCardBalance = updatedCardResponse.getBalance();

        // Create and save the transaction record
        Transaction transaction = modelMapper.map(transactionRequestDTO, Transaction.class);
        transaction.setTransactionDate(LocalDate.now());
        transaction.setBalance(updatedCardBalance);
        Transaction savedTransaction = transactionRepository.save(transaction);

        // Prepare and return the response
        TransactionResponseDTO responseDTO = modelMapper.map(savedTransaction, TransactionResponseDTO.class);
        responseDTO.setMessage(SuccessMessageUtil.TRANSACTION_CREATED_SUCCESSFULLY + " " + transactionRequestDTO.getTransactionType());
        return responseDTO;
    }
    @Override
    public TransactionResponseDTO getTransactionById(Long transactionId) {
        Transaction transaction = transactionRepository.findByTransactionId(transactionId)
                .orElseThrow(() -> new TransactionNotFoundException(ErrorMessageUtil.TRANSACTION_NOT_FOUND));
        return modelMapper.map(transaction, TransactionResponseDTO.class);
    }

    @Override
    public Page<TransactionResponseDTO> getAllTransactions(int page, int size, String sortBy, String sortDir) {
        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Transaction> transactionsPage = transactionRepository.findAll(pageable);
        return transactionsPage.map(transaction -> modelMapper.map(transaction, TransactionResponseDTO.class));
    }

    @Override
    public List<TransactionResponseDTO> getTransactionsByCardNumber(String cardNumber) {
        List<Transaction> transactions = transactionRepository.findByCardNumber(cardNumber);
        return transactions.stream()
                .map(transaction -> modelMapper.map(transaction, TransactionResponseDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public String deleteTransaction(Long transactionId) {
        Transaction transaction = transactionRepository.findByTransactionId(transactionId)
                .orElseThrow(() -> new TransactionNotFoundException(ErrorMessageUtil.TRANSACTION_NOT_FOUND));
        transactionRepository.delete(transaction);
        return SuccessMessageUtil.TRANSACTION_DELETED_SUCCESSFULLY;
    }

    @Override
    public Page<TransactionResponseDTO> getTransactionsByCardNumberAndDateRange(String cardNumber, LocalDate startDate, LocalDate endDate, Pageable pageable) {
        Page<Transaction> transactionPage = transactionRepository.findByCardNumberAndTransactionDateBetween(cardNumber, startDate, endDate, pageable);

        if (transactionPage.isEmpty()) {
            throw new TransactionNotFoundException(ErrorMessageUtil.TRANSACTION_NOT_FOUND);
        }
        return transactionPage.map(transaction -> modelMapper.map(transaction, TransactionResponseDTO.class));
    }

    //------------


}
