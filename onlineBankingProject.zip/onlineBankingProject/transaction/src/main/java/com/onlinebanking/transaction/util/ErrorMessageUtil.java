package com.onlinebanking.transaction.util;

public class ErrorMessageUtil {
    public static final String TRANSACTION_NOT_FOUND = "Transaction not found.";
    public static final String GENERAL_ERROR_MESSAGE = "An error occurred. Please try again later.";
    public static final String CARD_NOT_FOUND = "Card not found.";
    public static final String INSUFFICIENT_FUNDS = "Insufficient funds for this transaction.";
    public static final String CARD_SERVICE_ERROR = "Error occurred while communicating with card service.";

}
