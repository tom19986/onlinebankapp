package com.onlinebanking.transaction.util;

public class ErrorMessageUtil {
    public static final String TRANSACTION_NOT_FOUND = "Transaction not found.";
    public static final String GENERAL_ERROR_MESSAGE = "An error occurred. Please try again later.";
}
